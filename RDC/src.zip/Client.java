import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        int BUFFER_DIM = 100;
        Scanner keyboard = new Scanner(System.in);
        try {
            // indirizzo e porta server indicati come primo e secondo argomento cmd
            InetAddress serverIP = InetAddress.getByName(args[0]);
            int serverPort = Integer.parseInt(args[1]);
            Socket SO = new Socket(serverIP, serverPort);
            System.out.printf(
                    "CONNESSO CON IL SERVER %s:%d\n",
                    SO.getInetAddress().toString(),
                    SO.getPort()
            );
            InputStream in = SO.getInputStream();
            OutputStream out = SO.getOutputStream();
            byte[] bufferRicezione;
            int cont = 0; //numero di coefficienti corretti mandati
            while (true) {
                if (cont<3) { //leggo i coefficienti
                    String qualeCoef = null;
                    switch (cont){
                        case 0:
                            qualeCoef = "a";
                            break;
                        case 1:
                            qualeCoef = "b";
                            break;
                        case 2:
                            qualeCoef = "c";
                            break;
                    }
                    System.out.printf("%s: ", qualeCoef);
                    String sIn = keyboard.nextLine();
                    if (".".equals(sIn)) { //termino connessione
                        out.write(".".getBytes());
                        SO.close();
                        System.out.println("CONNESSIONE CHIUSA");
                        break;
                    }
                    try {
                        Double coef = Double.parseDouble(sIn);
                        out.write(Double.toString(coef).getBytes()); //Se giusto invia
                        cont++;
                    } catch (NumberFormatException e) { //Formato errato -> Richiede il valore
                        //continue; non serve in quanto ultimo statement
                    }
                } else { //aspetto soluzione
                    bufferRicezione = new byte[BUFFER_DIM];
                    int dim = in.read(bufferRicezione);
                    System.out.println(new String(bufferRicezione, 0, dim));
                    cont = 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
