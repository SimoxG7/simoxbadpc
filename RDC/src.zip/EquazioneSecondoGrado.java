import java.util.ArrayList;
import java.util.List;

public class EquazioneSecondoGrado {
    //ax^2 + bx + c
    private double a, b, c;

    public EquazioneSecondoGrado (double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public Double delta () {
        return (b*b - 4*a*c);
    }

    public boolean impossibile () {
        return delta()<0;
    }

    public List<Double> soluzioni () {
        double delta = delta();
        if (delta<0) {
            return new ArrayList<>();
        }
        double s1, s2;
        s1 = (-b + Math.sqrt(delta()))/2*a;
        if (delta==0)
            return List.of(s1);
        s2 = (-b - Math.sqrt(delta()))/2*a;
        return List.of(s1, s2);
    }

    public static void main(String[] args) {
        System.out.printf("%.2f",10.0/3.0);
    }

}
