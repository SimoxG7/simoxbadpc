import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.List;

public class Server {

    public static void main(String[] args) {
        int BUFFER_DIM = 100;
        int porta = Integer.parseInt(args[0]); //porta sui cui eseguire listen() come unico argomento da cmd
        try {
            ServerSocket SO = new ServerSocket(porta);
            Socket client;
            while (true) {
                client=SO.accept();
                System.out.printf(
                        "CLIENT %s:%d%n",
                        client.getInetAddress().toString(),
                        client.getPort()
                );
                InputStream in = client.getInputStream();
                OutputStream out = client.getOutputStream();
                byte[] bufferRicezione;
                boolean A = true, B = false; //stati di lettura, se A==true sto attendendo a
                double a=0, b=0, c;
                while (true) {
                    try {
                        bufferRicezione = new byte[BUFFER_DIM];
                        int dim = in.read(bufferRicezione);
                        String sIn = new String(bufferRicezione,0,dim);
                        System.out.printf("RICEVUTO: %s\n", sIn);
                        if (sIn.equals(".")) { // "." è la notifica di terminazione
                            System.out.printf(
                                    "IL CLIENT %s:%d HA CHIUSO LA CONNESSIONE\n",
                                    client.getInetAddress().toString(),
                                    client.getPort()
                            );
                            client.close();
                            break;
                        }
                        try { //verifico formato numero, se errato termino connesione
                            double val = Double.parseDouble(sIn);
                            if (A) { //attendo a
                                a = val;
                                A = false;
                                B = true;
                            } else if (B) { //attendo b
                                b = val;
                                B = false;
                            } else { //attendo c e fornisco soluzioni
                                c = val;
                                EquazioneSecondoGrado E = new EquazioneSecondoGrado(a,b,c);
                                String risposta;
                                List<Double> sol = E.soluzioni();
                                if (sol.size()==0)
                                    risposta = "L'EQUAZIONE NON HA SOLUZIONI";
                                else if (sol.size()==1)
                                    risposta = String.format(
                                            "SOLUZIONE 1 = %.2f",
                                            sol.get(0)
                                    );
                                else {
                                    risposta = String.format(
                                            "SOLUZIONE 1 = %.2f\nSOLUZIONE 2 = %.2f",
                                            sol.get(0),
                                            sol.get(1)
                                    );
                                }
                                out.write(risposta.getBytes());
                                A = true;
                                B = false;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("FORMATO NUMERO ERRATO; CONNESSIONE TERMINATA");
                            client.close();
                            break;
                        }
                    } catch (SocketException e) {
                        System.out.printf(
                                "IL CLIENT %s:%d HA CHIUSO LA CONNESSIONE\n",
                                client.getInetAddress().toString(),
                                client.getPort()
                                );
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
