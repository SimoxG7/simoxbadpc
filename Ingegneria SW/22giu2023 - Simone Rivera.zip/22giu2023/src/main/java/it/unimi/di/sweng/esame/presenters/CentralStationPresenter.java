package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.views.CentralStationView;
import org.jetbrains.annotations.NotNull;

public class CentralStationPresenter implements Presenter {

    private final @NotNull Model model;
    private final @NotNull CentralStationView view;


    public CentralStationPresenter(final @NotNull Model model, final @NotNull CentralStationView view) {
        this.model = model;
        this.view = view;
        view.addHandlers(this);
    }

    @Override
    public void action(final @NotNull String action, final @NotNull String roadNotice) {
        String result;
        if(action.equals("Segnala")) result = model.addRoadNotice(roadNotice);
        else result = model.closeRoadNotice(roadNotice);
        if(result.equals("ok")) view.showSuccess();
        else view.showError(result);
    }

}