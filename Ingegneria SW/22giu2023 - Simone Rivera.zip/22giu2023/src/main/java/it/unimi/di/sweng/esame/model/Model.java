package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.presenters.Observer;
import it.unimi.di.sweng.esame.roadnotice.RoadNotice;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class Model implements Observable<List<RoadNotice>> {

    private final int MAX_NOTICES;
    private final List<RoadNotice> activeRoadNotices = new ArrayList<>();
    private final List<RoadNotice> closedRoadNotices = new ArrayList<>();
    private final List<Observer<List<RoadNotice>>> observers = new ArrayList<>();

    public Model(final int maxNotices) {
        MAX_NOTICES = maxNotices;
    }

    public int maxNotices(){
        return MAX_NOTICES;
    }

    public @NotNull String addRoadNotice(final @NotNull String roadNotice) {
        if(activeRoadNotices.size() == MAX_NOTICES) return "Raggiunto numero massimo di segnalazioni attive";
        String[] parts = roadNotice.split(",");
        if(parts.length == 2) return "Campo descrizione mancante";
        if(parts.length != 3) return "Numero errato di campi";
        String stretch = parts[0].trim();
        int km;
        try {
            km = Integer.parseInt(parts[1].trim());
        } catch (NumberFormatException e){
            return "Campo km non numerico";
        }
        parts[2] = parts[2].trim();
        String description =  parts[2].substring(0,1).toUpperCase() + parts[2].substring(1);
        for(RoadNotice rn : activeRoadNotices)
            if(rn.stretch().equals(stretch) && rn.km() == km) return "Altra segnalazione già presente per questo tratto";
        activeRoadNotices.add(new RoadNotice(stretch, km, description));
        notifyObservers();
        return "ok";
    }

    public @NotNull List<RoadNotice> getActiveRoadNotices() {
        return new ArrayList<>(activeRoadNotices);
    }

    public @NotNull String closeRoadNotice(final @NotNull String roadNotice) {
        String[] parts = roadNotice.split(",");
        if(parts.length != 2) return "Numero errato di campi";
        String stretch = parts[0].trim();
        int km;
        try {
            km = Integer.parseInt(parts[1].trim());
        } catch (NumberFormatException e){
            return "Campo km non numerico";
        }
        for(RoadNotice rn : activeRoadNotices) {
            if (rn.stretch().equals(stretch) && rn.km() == km) {
                activeRoadNotices.remove(rn);
                closedRoadNotices.add(rn);
                notifyObservers();
                return "ok";
            }
        }
        return "Segnalazione non presente per questo tratto";
    }

    public @NotNull List<RoadNotice> getClosedRoadNotices() {
        return new ArrayList<>(closedRoadNotices);
    }

    @Override
    public void addObserver(final @NotNull Observer<List<RoadNotice>> observer) {
        observers.add(observer);
    }

    @Override
    public void notifyObservers() {
        for(Observer<List<RoadNotice>> observer : observers)
            observer.update(this, null);
    }

}