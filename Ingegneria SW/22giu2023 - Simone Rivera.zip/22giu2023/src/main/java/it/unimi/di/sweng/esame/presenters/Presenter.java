package it.unimi.di.sweng.esame.presenters;

public interface Presenter {
  void action(String text1, String text2);
}
