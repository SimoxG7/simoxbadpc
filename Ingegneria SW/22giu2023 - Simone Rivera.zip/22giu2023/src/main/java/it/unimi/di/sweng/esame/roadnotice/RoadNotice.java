package it.unimi.di.sweng.esame.roadnotice;

import org.jetbrains.annotations.NotNull;

public record RoadNotice(@NotNull String stretch, int km, @NotNull String description) implements Comparable<RoadNotice> {

    @Override
    public @NotNull String toString(){
        return description + " sulla " + stretch + " al km " + km;
    }

    @Override
    public int compareTo(final @NotNull RoadNotice roadNotice) {
        int s1 = Integer.parseInt(stretch.substring(1));
        int s2 = Integer.parseInt(roadNotice.stretch.substring(1));
        if(s1 == s2) return km - roadNotice.km();
        return s1 - s2;
    }

}