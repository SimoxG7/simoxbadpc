package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.model.Observable;
import it.unimi.di.sweng.esame.roadnotice.RoadNotice;
import it.unimi.di.sweng.esame.views.DisplayView;
import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.List;

public class ActiveRoadNoticePresenter implements Observer<List<RoadNotice>> {

    private final @NotNull DisplayView view;

    public ActiveRoadNoticePresenter(final @NotNull Model model, final @NotNull DisplayView view) {
        model.addObserver(this);
        this.view = view;
    }

    @Override
    public void update(final @NotNull Observable<List<RoadNotice>> observable, final List<RoadNotice> state) {
        if(!(observable instanceof Model model)) return;
        List<RoadNotice> roadNotices = model.getActiveRoadNotices();
        Collections.sort(roadNotices);
        for(int i = 0; i < model.maxNotices() && i < roadNotices.size(); i++) {
            view.set(i, roadNotices.get(i).toString());
            System.out.println(i);
        }
        for(int i = roadNotices.size(); i < model.maxNotices(); i++)
            view.set(i, "");
    }

}