package it.unimi.di.sweng.esame.model;

import it.unimi.di.sweng.esame.presenters.Observer;
import it.unimi.di.sweng.esame.roadnotice.RoadNotice;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TestModel {

    private @NotNull Model SUT;

    private final int MAX_NOTICES = 8;

    @BeforeEach
    public void setup(){
        SUT = new Model(MAX_NOTICES);
    }

    @Test
    public void maxNotices(){
        assertThat(SUT.maxNotices()).isEqualTo(MAX_NOTICES);
    }

    @Test
    public void addRoadNotice(){
        assertThat(SUT.addRoadNotice("A1,57,incidente")).isEqualTo("ok");
        assertThat(SUT.getActiveRoadNotices()).isEqualTo(List.of(new RoadNotice("A1",57,"Incidente")));
    }

    @Test
    public void addRoadNoticeDouble(){
        SUT.addRoadNotice("A1,57,incidente");
        assertThat(SUT.addRoadNotice("A1,57,traffico")).isEqualTo("Altra segnalazione già presente per questo tratto");
        assertThat(SUT.getActiveRoadNotices()).isEqualTo(List.of(new RoadNotice("A1",57,"Incidente")));
    }

    @Test
    public void addRoadNoticeKmNotNumber(){
        assertThat(SUT.addRoadNotice("A1,b,incidente")).isEqualTo("Campo km non numerico");
        assertThat(SUT.getActiveRoadNotices()).isEqualTo(new ArrayList<>());
    }

    @Test
    public void addRoadNoticeMissingDescription(){
        assertThat(SUT.addRoadNotice("A1,57")).isEqualTo("Campo descrizione mancante");
        assertThat(SUT.getActiveRoadNotices()).isEqualTo(new ArrayList<>());
    }

    @Test
    public void addRoadNoticeMax(){
        SUT.addRoadNotice("A1,57,incidente");
        SUT.addRoadNotice("A2,57,incidente");
        SUT.addRoadNotice("A3,57,incidente");
        SUT.addRoadNotice("A4,57,incidente");
        SUT.addRoadNotice("A5,57,incidente");
        SUT.addRoadNotice("A6,57,incidente");
        SUT.addRoadNotice("A7,57,incidente");
        SUT.addRoadNotice("A8,57,incidente");
        assertThat(SUT.addRoadNotice("A9,57,incidente")).isEqualTo("Raggiunto numero massimo di segnalazioni attive");
        assertThat(SUT.getActiveRoadNotices()).isEqualTo(List.of(
                new RoadNotice("A1",57,"Incidente"),
                new RoadNotice("A2",57,"Incidente"),
                new RoadNotice("A3",57,"Incidente"),
                new RoadNotice("A4",57,"Incidente"),
                new RoadNotice("A5",57,"Incidente"),
                new RoadNotice("A6",57,"Incidente"),
                new RoadNotice("A7",57,"Incidente"),
                new RoadNotice("A8",57,"Incidente")
        ));
    }

    @Test
    public void closeRoadNotice(){
        SUT.addRoadNotice("A1,57,incidente");
        assertThat(SUT.closeRoadNotice("A1,57")).isEqualTo("ok");
        assertThat(SUT.getActiveRoadNotices()).isEqualTo(new ArrayList<>());
        assertThat(SUT.getClosedRoadNotices()).isEqualTo(List.of(new RoadNotice("A1",57,"Incidente")));
    }

    @Test
    public void closeRoadNoticeNotExists(){
        SUT.addRoadNotice("A1,57,incidente");
        assertThat(SUT.closeRoadNotice("A1,56")).isEqualTo("Segnalazione non presente per questo tratto");
        assertThat(SUT.getActiveRoadNotices()).isEqualTo(List.of(new RoadNotice("A1",57,"Incidente")));
        assertThat(SUT.getClosedRoadNotices()).isEqualTo(new ArrayList<>());
    }

    @Test
    public void closeRoadNoticeKmNotNumber(){
        SUT.addRoadNotice("A1,57,incidente");
        assertThat(SUT.closeRoadNotice("A1,b")).isEqualTo("Campo km non numerico");
        assertThat(SUT.getActiveRoadNotices()).isEqualTo(List.of(new RoadNotice("A1",57,"Incidente")));
        assertThat(SUT.getClosedRoadNotices()).isEqualTo(new ArrayList<>());
    }

    @Test
    public void addRoadNoticeNotify(){
        Observer<List<RoadNotice>> observer = mock(Observer.class);
        SUT.addObserver(observer);
        SUT.addRoadNotice("A1,57,incidente");
        SUT.addRoadNotice("A2,57,incidente");
        SUT.addRoadNotice("A3,57,incidente");
        SUT.addRoadNotice("A4,57,incidente");
        SUT.addRoadNotice("A5,57,incidente");
        SUT.addRoadNotice("A6,57,incidente");
        SUT.addRoadNotice("A7,57,incidente");
        SUT.addRoadNotice("A8,57,incidente");
        SUT.addRoadNotice("A9,57,incidente");
        SUT.addRoadNotice("A1,57,incidente");
        SUT.addRoadNotice("A1,56");
        SUT.addRoadNotice("A1,b,incidente");
        verify(observer, times(8)).update(SUT, null);
    }

    @Test
    public void closeRoadNoticeNotify(){
        Observer<List<RoadNotice>> observer = mock(Observer.class);
        SUT.addObserver(observer);
        SUT.addRoadNotice("A1,57,incidente");
        SUT.closeRoadNotice("A1,57");
        SUT.closeRoadNotice("A1,56");
        SUT.closeRoadNotice("A1,b");
        verify(observer, times(2)).update(SUT, null);
    }

}