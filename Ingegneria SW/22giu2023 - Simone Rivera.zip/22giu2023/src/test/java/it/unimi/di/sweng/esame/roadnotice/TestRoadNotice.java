package it.unimi.di.sweng.esame.roadnotice;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.*;

public class TestRoadNotice {

    @Test
    public void toStringTest(){
        RoadNotice SUT = new RoadNotice("A1", 57, "Incidente");
        assertThat(SUT.toString()).isEqualTo("Incidente sulla A1 al km 57");
    }

    @Test
    public void compareToLess(){
        RoadNotice SUT = new RoadNotice("A1",57,"Incidente");
        assertThat(SUT.compareTo(new RoadNotice("A4", 32, "Traffico"))).isEqualTo(-3);
    }

    @Test
    public void compareToGreater(){
        RoadNotice SUT = new RoadNotice("A5",17,"Incidente");
        assertThat(SUT.compareTo(new RoadNotice("A1", 53, "Traffico"))).isEqualTo(4);
    }

    @Test
    public void compareToKmGreater(){
        RoadNotice SUT = new RoadNotice("A1",57,"Incidente");
        assertThat(SUT.compareTo(new RoadNotice("A1", 32, "Traffico"))).isEqualTo(25);
    }

    @Test
    public void compareToKmLess(){
        RoadNotice SUT = new RoadNotice("A1",17,"Incidente");
        assertThat(SUT.compareTo(new RoadNotice("A1", 32, "Traffico"))).isEqualTo(-15);
    }

    @Test
    public void compareToEquals(){
        RoadNotice SUT = new RoadNotice("A1",17,"Incidente");
        assertThat(SUT.compareTo(new RoadNotice("A1", 17, "Traffico"))).isEqualTo(0);
    }

}