package it.unimi.di.sweng.esame.presenters;

import it.unimi.di.sweng.esame.model.Model;
import it.unimi.di.sweng.esame.roadnotice.RoadNotice;
import it.unimi.di.sweng.esame.views.CentralStationView;
import it.unimi.di.sweng.esame.views.DisplayView;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

public class TestPresenters {

    @Test
    public void centralStationPresenter(){
        CentralStationView view = mock(CentralStationView.class);
        CentralStationPresenter SUT = new CentralStationPresenter(mock(Model.class), view);
        verify(view).addHandlers(SUT);
    }

    @Test
    public void centralStationPresenterAction(){
        CentralStationView view = mock(CentralStationView.class);
        Model model = mock(Model.class);
        when(model.addRoadNotice("A1,57,incidente")).thenReturn("ok");
        CentralStationPresenter SUT = new CentralStationPresenter(model, view);
        SUT.action("Segnala", "A1,57,incidente");
        verify(view).showSuccess();
    }

    @Test
    public void centralStationPresenterActionAddError(){
        CentralStationView view = mock(CentralStationView.class);
        Model model = mock(Model.class);
        when(model.addRoadNotice("A1,57,incidente")).thenReturn("errore");
        CentralStationPresenter SUT = new CentralStationPresenter(model, view);
        SUT.action("Segnala", "A1,57,incidente");
        verify(view).showError("errore");
    }

    @Test
    public void centralStationPresenterActionClose(){
        CentralStationView view = mock(CentralStationView.class);
        Model model = mock(Model.class);
        when(model.closeRoadNotice("A1,57")).thenReturn("ok");
        CentralStationPresenter SUT = new CentralStationPresenter(model, view);
        SUT.action("Risolto", "A1,57");
        verify(view).showSuccess();
    }

    @Test
    public void centralStationPresenterActionCloseError(){
        CentralStationView view = mock(CentralStationView.class);
        Model model = mock(Model.class);
        when(model.closeRoadNotice("A1,57")).thenReturn("errore");
        CentralStationPresenter SUT = new CentralStationPresenter(model, view);
        SUT.action("Risolto", "A1,57");
        verify(view).showError("errore");
    }

    @Test
    public void activeRoadNoticePresenter(){
        Model model = mock(Model.class);
        ActiveRoadNoticePresenter SUT = new ActiveRoadNoticePresenter(model, mock(DisplayView.class));
        verify(model).addObserver(SUT);
    }

    @Test
    public void activeRoadNoticePresenterUpdate(){
        Model model = mock(Model.class);
        DisplayView view = mock(DisplayView.class);
        List<RoadNotice> roadNotices = new ArrayList<>();
        roadNotices.add(new RoadNotice("A7",45,"Incidente"));
        roadNotices.add(new RoadNotice("A7",23,"Traffico"));
        roadNotices.add(new RoadNotice("A1",73,"Incidente"));
        when(model.getActiveRoadNotices()).thenReturn(roadNotices);
        when(model.maxNotices()).thenReturn(8);
        ActiveRoadNoticePresenter SUT = new ActiveRoadNoticePresenter(model, view);
        SUT.update(model, null);
        verify(view).set(0, "Incidente sulla A1 al km 73");
        verify(view).set(1, "Traffico sulla A7 al km 23");
        verify(view).set(2, "Incidente sulla A7 al km 45");
        verify(view).set(3, "");
        verify(view).set(7, "");
    }

    @Test
    public void closedRoadNoticePresenter(){
        Model model = mock(Model.class);
        ClosedRoadNoticePresenter SUT = new ClosedRoadNoticePresenter(model, mock(DisplayView.class));
        verify(model).addObserver(SUT);
    }

    @Test
    public void closedRoadNoticePresenterUpdate(){
        Model model = mock(Model.class);
        DisplayView view = mock(DisplayView.class);
        List<RoadNotice> roadNotices = new ArrayList<>();
        roadNotices.add(new RoadNotice( "A7",23,"Traffico"));
        roadNotices.add(new RoadNotice("A7",45,"Incidente"));
        roadNotices.add(new RoadNotice("A1",73,"Incidente"));
        when(model.getClosedRoadNotices()).thenReturn(roadNotices);
        when(model.maxNotices()).thenReturn(8);
        ClosedRoadNoticePresenter SUT = new ClosedRoadNoticePresenter(model, view);
        SUT.update(model, null);
        verify(view).set(0, "Incidente sulla A1 al km 73");
        verify(view).set(1, "Incidente sulla A7 al km 45");
        verify(view).set(2, "Traffico sulla A7 al km 23");
        verify(view).set(3, "");
        verify(view).set(7, "");
    }

}